#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <time.h>
#include "auto_test.h"
#include "cJSON.h"

#define REC_KEY_DOWN			0x01
#define AUDIO_KEY_DOWN			0x02
#define LOCK_KEY_DOWN			0x04
#define CAPTURE_KEY_DOWN		0x08

#define KEY_SHORT_DOWN			0x10
#define KEY_LONG_DOWN			0x20

//ģ�ⳤ�����̰���ʱ��
#define SHORT_DOWN_KEEP_US		(100*1000)//100ms
#define LONG_DOWN_KEEP_US		(1500*1000)//1.5s


//config file path
#define 		AUTO_KEY_FILE			"/auto_test.cfg"
//const define
#define 		KEY_VALUE_REC_D			"REC_KEY"
#define 		KEY_VALUE_AUDIO_D		"AUDIO_KEY"
#define 		KEY_VALUE_LOCK_D		"LOCK_KEY"
#define 		KEY_VALUE_CAPTURE_D		"CAPTURE_KEY"
#define 		KEY_ACTION_PRESS_D		"PRESS"
#define 		KEY_ACTION_L_PRESS_D	"LONG_PRESS"


static const char *CMD_ID_TAG			="CMD";

static const char *KEY_SEQUENCE_TAG		="key_sequence";
static const char *KEY_VALUE_TAG    	="key_value";
static const char *KEY_ACTION_TAG	 	="key_action";
static const char *KEY_DELAY_SEC_TAG	="key_delay_seconds";


static const char *LOOP_TAG				="loop_count";

/*static const char *KEY_VALUE_REC		=KEY_VALUE_REC_D;
static const char *KEY_VALUE_AUDIO		=KEY_VALUE_AUDIO_D;
static const char *KEY_VALUE_LOCK		=KEY_VALUE_LOCK_D;
static const char *KEY_VALUE_CAPTURE	=KEY_VALUE_CAPTURE_D;
static const char *KEY_ACTION_PRESS		=KEY_ACTION_PRESS_D;
static const char *KEY_ACTION_L_PRESS	=KEY_ACTION_L_PRESS_D;*/

static const char *SEQUENCE_KEY_CMD     ="sequence_key";
static const char *RANDOM_KEY_CMD     	="random_key";


//auto key
static pthread_spinlock_t g_virtual_key_lock;
static int g_virtual_key_status = -1;
static int g_virtual_key_enabled = 1;


typedef struct _AUTO_KEY_ACTION{
	int key_value;//ģ��İ���ֵ
	int key_action;//ģ�ⳤ�����Ƕ̰�
	int key_delay; //��ǰ��������һ��������ʱ����

}AUTO_KEY_ACTION;

typedef struct _INT_STRING_MAP{
	int iV;
	char *sV;
}INT_STRING_MAP;

//
#define GET_VIRTUAL_KEY_STATUS(ret) \
	pthread_spin_lock(&g_virtual_key_lock);\
	ret=g_virtual_key_status;\
	pthread_spin_unlock(&g_virtual_key_lock);

#define SET_VIRTUAL_KEY_STATUS(value)\
	pthread_spin_lock(&g_virtual_key_lock);\
	g_virtual_key_status=value;\
	pthread_spin_unlock(&g_virtual_key_lock);



//INT_STRING_MAP��iVȷ��Ϊ������
static int string_to_int(const char *str,INT_STRING_MAP *map_data,int size)
{
	int i;

	if(str!=NULL)
	{
		for(i=0;i<size;i++)
		{
			if(strcmp(str,map_data[i].sV)==0)
			{
				return map_data[i].iV;
			}
		}
	}
	return -1;
}
//
static char* int_to_string(int in,INT_STRING_MAP *map_data,int size)
{
	int i;

	for(i=0;i<size;i++)
	{
		if(map_data[i].iV==in)
		{
			return map_data[i].sV;
		}
	}

	return NULL;
}

static INT_STRING_MAP s_key_value_map[]={
	{REC_KEY_DOWN,KEY_VALUE_REC_D},
	{AUDIO_KEY_DOWN,KEY_VALUE_AUDIO_D},
	{LOCK_KEY_DOWN,KEY_VALUE_LOCK_D},
	{CAPTURE_KEY_DOWN,KEY_VALUE_CAPTURE_D}
};

static INT_STRING_MAP s_key_action_map[]={
	{KEY_SHORT_DOWN,KEY_ACTION_PRESS_D},
	{KEY_LONG_DOWN,KEY_ACTION_L_PRESS_D}
};

#define GET_KEY_STRING(v) int_to_string(v,s_key_value_map,sizeof(s_key_value_map)/sizeof(s_key_value_map[0]))
#define GET_KEY_VALUE(s)  string_to_int(s,s_key_value_map,sizeof(s_key_value_map)/sizeof(s_key_value_map[0]))
#define GET_ACTION_STRING(v) int_to_string(v,s_key_action_map,sizeof(s_key_action_map)/sizeof(s_key_action_map[0]))	
#define GET_ACTION_VALUE(s) string_to_int(s,s_key_action_map,sizeof(s_key_action_map)/sizeof(s_key_action_map[0]))

//
static cJSON * create_sequence_key_cmd(int loop,AUTO_KEY_ACTION *seq,int size)
{
	int i;
	cJSON *root,*seq_array,*item;

	if((root=cJSON_CreateObject())==NULL)
	{
		return NULL;
	}

	cJSON_AddStringToObject(root,CMD_ID_TAG,SEQUENCE_KEY_CMD);
	cJSON_AddNumberToObject(root,LOOP_TAG,loop);

	if((seq_array=cJSON_CreateArray())==NULL)
	{
		goto err_out;
	}
	cJSON_AddItemToObject(root,KEY_SEQUENCE_TAG,seq_array);

	for(i=0;i<size;i++)
	{
		if((item=cJSON_CreateObject())==NULL)
		{
			goto err_out;
		}
		cJSON_AddStringToObject(item,KEY_VALUE_TAG,GET_KEY_STRING(seq[i].key_value));
		cJSON_AddStringToObject(item,KEY_ACTION_TAG,GET_ACTION_STRING(seq[i].key_action));
		cJSON_AddNumberToObject(item,KEY_DELAY_SEC_TAG,seq[i].key_delay);

		cJSON_AddItemToArray(seq_array,item);
	}
	return root;
	
err_out:
	cJSON_Delete(root);
	return NULL;
}
//
static int writen(int fd,void *buffer,int n)
{
	int wr;
	unsigned char *pStart =(unsigned char *)buffer;

	while(n > 0)
	{
		wr=write(fd,pStart,n);
		if(wr < 0 && errno!=EINTR)
		{
			return -1;
		}

		pStart+=wr;
		n-=wr;
	}

	return 0;
}
//
static int readn(int fd,void *buffer,int n)
{
	int rd;
	unsigned char *pStart =(unsigned char *)buffer;

	while(n > 0)
	{
		rd=read(fd,pStart,n);
		if(rd < 0 && errno!=EINTR)
		{
			return -1;
		}
		else if(rd == 0)
		{
			break;
		}
		
		pStart+=rd;
		n-=rd;
	}

	return 0;
}
//
static void test_create_sequence_key_cmd(void)
{
	static int test_once = 0;
	cJSON *root;
	AUTO_KEY_ACTION seq[]={{REC_KEY_DOWN,KEY_SHORT_DOWN,1},
		{LOCK_KEY_DOWN,KEY_LONG_DOWN,2},
		{AUDIO_KEY_DOWN,KEY_LONG_DOWN,5},
		{CAPTURE_KEY_DOWN,KEY_SHORT_DOWN,2}};
	int fd;
	char *result;

	if(test_once==0)
	{
		root=create_sequence_key_cmd(3,seq,sizeof(seq)/sizeof(seq[0]));

		if(root==NULL)
		{
			printf("*************Fail*******************\n");
		}
		else
		{
			if((result=cJSON_Print(root))!=NULL)
			{
				if((fd=open(AUTO_KEY_FILE,O_WRONLY|O_TRUNC|O_CREAT))>=0)
				{
					if(writen(fd,result,strlen(result))==0)
					{
						test_once++;
					}
					
					close(fd);
				}
				else
				{
					printf("*****************Error:%s*******************\n",strerror(errno));
				}
			}
		}
	}
}
//
static void * read_toatl_text_file(const char *path)
{
	int fd;
	struct stat f_stat;
	unsigned char *ret = NULL;
	
	if((fd=open(path,O_RDONLY)) < 0)
	{
		return NULL;
	}
	if(fstat(fd,&f_stat) < 0)
	{
		goto out;
	}
	
	if((ret = (unsigned char*)malloc(f_stat.st_size+2))==NULL)
	{
		goto out;
	}

	if(readn(fd,ret,f_stat.st_size) < 0)
	{
		free(ret);
		ret = NULL;
	}
	else
	{
		ret[f_stat.st_size] = 0;
		ret[f_stat.st_size+1] = 0;
	}
out:
	close(fd);
	return ret;
}
//
static cJSON * load_auto_key_config(const char *path)
{
	cJSON *root=NULL;
	char * cfg = read_toatl_text_file(path);

	if(cfg!=NULL)
	{
		root = cJSON_Parse(cfg);
		free(cfg);
	}

	return root;
}
//
static int json_get_int(cJSON *root,const char *name,int *ret)
{
	cJSON *item=cJSON_GetObjectItem(root,name);
	if(item==NULL || item->type!=cJSON_Number)
	{
		return -1;
	}

	*ret=item->valueint;
	return 0;
}
//
static char* json_get_string(cJSON *root,const char *name)
{
	cJSON *item=cJSON_GetObjectItem(root,name);
	if(item==NULL || item->type!=cJSON_String)
	{
		return NULL;
	}

	return item->valuestring;
}
//
void *key_simulate(void *null)
{

	int key_type[]={KEY_SHORT_DOWN,KEY_SHORT_DOWN,KEY_SHORT_DOWN,KEY_SHORT_DOWN,KEY_SHORT_DOWN,
					KEY_SHORT_DOWN,KEY_SHORT_DOWN,KEY_SHORT_DOWN,KEY_SHORT_DOWN,KEY_SHORT_DOWN,
					KEY_LONG_DOWN,KEY_LONG_DOWN};
					
	int key_value[]={REC_KEY_DOWN,AUDIO_KEY_DOWN,CAPTURE_KEY_DOWN,LOCK_KEY_DOWN};

	int vKey_type,vKey_value,vKey_keep;

	cJSON *cmd_root=load_auto_key_config(AUTO_KEY_FILE),*seq=NULL,*seq_item;
	char *cmd;

	int random = -1;
	int loop_count,seq_key_size;
	int loop_index=0,current_key_index=0,current_delay=0;

	if(cmd_root!=NULL)
	{
		cmd=json_get_string(cmd_root,CMD_ID_TAG);
		if(cmd!=NULL)
		{
			if(json_get_int(cmd_root,LOOP_TAG,&loop_count)==0&&strcmp(cmd,SEQUENCE_KEY_CMD)==0)//���а���
			{
				seq=cJSON_GetObjectItem(cmd_root,KEY_SEQUENCE_TAG);
				if(seq->type==cJSON_Array)
				{
					seq_key_size=cJSON_GetArraySize(seq);
					random = 0;
				}
			}
			else if(strcmp(cmd,RANDOM_KEY_CMD)==0)//�������
			{
				random = 1;
				if(json_get_int(cmd_root,KEY_DELAY_SEC_TAG,&current_delay) < 0)
				{
					current_delay = 2;
				}
				srand(time(NULL));
			}
			
		} 
		
	}



    while(1)
    {

       if(g_virtual_key_enabled==0||random < 0)
       {
       		break;
       }
       
	   if(random)
	   {
	   		vKey_value = key_value[rand()%(sizeof(key_value)/sizeof(key_value[0]))];
	   		vKey_type = key_type[rand()%(sizeof(key_type)/sizeof(key_type[0]))];
	   }
	   else
	   {
	   		
   			if(current_key_index>=seq_key_size)//һ��ѭ���Ѿ����
   			{
   				loop_index ++;
   				current_key_index=0;
   			}

   			if(loop_index >=loop_count&&loop_count!=0)//����ѭ���Ѿ����꣬loop_count==0��������ѭ��
   			{
   				break;
   			}

   			seq_item=cJSON_GetArrayItem(seq,current_key_index);
   			vKey_value=GET_KEY_VALUE(json_get_string(seq_item,KEY_VALUE_TAG));
   			vKey_type=GET_ACTION_VALUE(json_get_string(seq_item,KEY_ACTION_TAG));
   			if(json_get_int(seq_item,KEY_DELAY_SEC_TAG,&current_delay) < 0)
   			{
   				vKey_value = -1;
   			}
   			
			current_key_index++;

   			if(vKey_value < 0 || vKey_type < 0)//��������ã�����
   			{
   				continue;
   			}
	   			
	   } 
	  

		if(vKey_type==KEY_SHORT_DOWN)
		{
			vKey_keep = SHORT_DOWN_KEEP_US;//ģ��̰�
		}
		else
		{
			vKey_keep = LONG_DOWN_KEEP_US;//ģ�ⳤ��
		}
		SET_VIRTUAL_KEY_STATUS(vKey_value);
   		usleep(vKey_keep);
		SET_VIRTUAL_KEY_STATUS(-1);
   		usleep(current_delay*1000000);
       
    }

    cJSON_Delete(cmd_root);

    return NULL;
}
extern int GK_SetPthreadStackSize(pthread_attr_t * attr, int stacksize);
static int auto_test_virtual_key_start(void)
{
    pthread_t pid;
    pthread_attr_t attr;

	pthread_spin_init(&g_virtual_key_lock, PTHREAD_PROCESS_PRIVATE);
    GK_SetPthreadStackSize(&attr, 524288);
    int ret = pthread_create(&pid, &attr, key_simulate, NULL);
    if (ret < 0)
    {
        printf("Start Virtual Key Error!\n");
        return -1;
    }
    
	printf("Start Virtual Key Successfully!\n");

    return 0;
}

void auto_test_init(void)
{
	auto_test_virtual_key_start();
}

//���ⰴ���Ƿ�����
int auto_test_is_virtual_key_actived(void)
{
	return g_virtual_key_enabled;
}
//�������ⰴ��
void auto_test_enable_virtual_key(void)
{
	g_virtual_key_enabled = 1;
}
//��ֹ���ⰴ��
void auto_test_disable_virtual_key(void)
{
	g_virtual_key_enabled = 0;
}
//��ȡ�Ǹ����ⰴ��������
int auto_test_get_virtual_key_status(void)
{
	int ret=-1;
	if(g_virtual_key_enabled)
	{		
		GET_VIRTUAL_KEY_STATUS(ret);
	}

	return ret;
}
//file end
